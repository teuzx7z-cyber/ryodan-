package com.ryodan.cut;

import android.content.Context;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.util.*;

/** Software frame extraction + hardware H264 encoding. Supports animated transformations and audio copy. */
public final class AnimatedExporter {
  private static MainActivity.Transform at(TreeMap<Integer,MainActivity.Transform> keys,int ms){
    Map.Entry<Integer,MainActivity.Transform> a=keys.floorEntry(ms),b=keys.ceilingEntry(ms);
    if(a==null&&b==null)return new MainActivity.Transform(1,0,0);
    if(a==null)return b.getValue().copy();if(b==null||a.getKey().equals(b.getKey()))return a.getValue().copy();
    float f=(ms-a.getKey())/(float)(b.getKey()-a.getKey());MainActivity.Transform v=a.getValue(),w=b.getValue();
    return new MainActivity.Transform(v.zoom+(w.zoom-v.zoom)*f,v.x+(w.x-v.x)*f,v.y+(w.y-v.y)*f);
  }
  private static int drain(MediaCodec encoder,MediaMuxer muxer,int videoTrack,MediaCodec.BufferInfo info,boolean end) throws Exception {
    int empty=0;
    while(true){int idx=encoder.dequeueOutputBuffer(info,end?100000:10000);
      if(idx==MediaCodec.INFO_TRY_AGAIN_LATER){if(!end||++empty>100)break;continue;}
      if(idx==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){if(videoTrack>=0)throw new Exception("Formato duplicado");videoTrack=muxer.addTrack(encoder.getOutputFormat());muxer.start();continue;}
      if(idx>=0){ByteBuffer out=encoder.getOutputBuffer(idx);if(out!=null&&info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0){if(videoTrack<0)throw new Exception("Faixa de vídeo indisponível");out.position(info.offset);out.limit(info.offset+info.size);muxer.writeSampleData(videoTrack,out,info);}boolean eos=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;encoder.releaseOutputBuffer(idx,false);if(eos)break;}
    }
    return videoTrack;
  }
  public static void export(Context context,Uri source,Uri destination,int start,int end,TreeMap<Integer,MainActivity.Transform> keys)throws Exception {
    MediaMetadataRetriever retriever=new MediaMetadataRetriever();MediaCodec encoder=null;MediaMuxer muxer=null;Surface surface=null;ParcelFileDescriptor fd=null;MediaExtractor audioExtractor=null;int audioTrack=-1;
    try{
      retriever.setDataSource(context,source);
      int sourceW=Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
      int sourceH=Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
      int rotation=0;try{rotation=Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));}catch(Exception ignored){}
      int width=Math.max(2,sourceW&~1),height=Math.max(2,sourceH&~1);
      // H.264 encoders commonly require even dimensions. Cap resolution to 1080p for mobile memory.
      float scale=Math.min(1f,Math.min(1920f/width,1080f/height));width=Math.max(2,((int)(width*scale))&~1);height=Math.max(2,((int)(height*scale))&~1);
      final int fps=30;
      MediaFormat format=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,width,height);
      format.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
      format.setInteger(MediaFormat.KEY_BIT_RATE,Math.max(900000,Math.min(8000000,width*height*3)));
      format.setInteger(MediaFormat.KEY_FRAME_RATE,fps);format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2);
      encoder=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);encoder.configure(format,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);surface=encoder.createInputSurface();encoder.start();
      fd=context.getContentResolver().openFileDescriptor(destination,"w");if(fd==null)throw new Exception("Não foi possível abrir o destino");
      muxer=new MediaMuxer(fd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
      // Register the source audio track before muxer.start(), which occurs at video format change.
      audioExtractor=new MediaExtractor();audioExtractor.setDataSource(context,source,null);
      for(int i=0;i<audioExtractor.getTrackCount();i++){
        MediaFormat af=audioExtractor.getTrackFormat(i);
        String mime=af.getString(MediaFormat.KEY_MIME);
        if(mime!=null && (mime.equals("audio/mp4a-latm") || mime.equals("audio/mpeg"))){
          audioTrack=muxer.addTrack(af);audioExtractor.selectTrack(i);break;
        }
      }
      // Frames are rendered into the encoder surface at 30fps, so the export runs in real time.
      MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();int track=-1;
      long totalUs=(end-start)*1000L;long frameUs=1000000L/fps;
      long begun=System.nanoTime();
      Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);paint.setColor(Color.BLACK);
      for(long t=0;t<totalUs;t+=frameUs){
        long target=begun+t*1000L;long wait=target-System.nanoTime();if(wait>0)android.os.SystemClock.sleep(Math.max(1,wait/1000000));
        int ms=start+(int)(t/1000L);Bitmap frame=retriever.getFrameAtTime(ms*1000L,MediaMetadataRetriever.OPTION_CLOSEST);
        Canvas canvas=surface.lockCanvas(null);try{
          canvas.drawColor(Color.BLACK);
          if(frame!=null){MainActivity.Transform tr=at(keys,ms);canvas.save();canvas.translate(width/2f+tr.x*width/2f,height/2f+tr.y*height/2f);canvas.scale(tr.zoom,tr.zoom);
            float ratio=Math.min(width/(float)frame.getWidth(),height/(float)frame.getHeight());float w=frame.getWidth()*ratio,h=frame.getHeight()*ratio;
            paint.setAlpha(255);canvas.drawBitmap(frame,null,new RectF(-w/2,-h/2,w/2,h/2),paint);canvas.restore();frame.recycle();}
        }finally{surface.unlockCanvasAndPost(canvas);}
        track=drain(encoder,muxer,track,info,false);
      }
      encoder.signalEndOfInputStream();track=drain(encoder,muxer,track,info,true);
      // Copy compressed audio packets without decoding; timestamps are rebased to trim start.
      if(audioTrack>=0){
        audioExtractor.seekTo(start*1000L,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        ByteBuffer audioBuffer=ByteBuffer.allocateDirect(1024*1024);
        MediaCodec.BufferInfo audioInfo=new MediaCodec.BufferInfo();
        long lastPts=-1;
        while(true){
          long pts=audioExtractor.getSampleTime();
          if(pts<0 || pts>=end*1000L)break;
          if(pts<start*1000L){audioExtractor.advance();continue;}
          audioBuffer.clear();int count=audioExtractor.readSampleData(audioBuffer,0);
          if(count<0)break;
          long outputPts=pts-start*1000L;
          if(outputPts<=lastPts)outputPts=lastPts+1;
          audioInfo.set(0,count,outputPts,audioExtractor.getSampleFlags() & MediaCodec.BUFFER_FLAG_KEY_FRAME);
          audioBuffer.position(0);audioBuffer.limit(count);
          muxer.writeSampleData(audioTrack,audioBuffer,audioInfo);lastPts=outputPts;
          audioExtractor.advance();
        }
      }
      muxer.stop();muxer.release();muxer=null;
    }finally{
      if(surface!=null)surface.release();if(encoder!=null){try{encoder.stop();}catch(Exception ignored){}encoder.release();}
      if(muxer!=null){try{muxer.stop();}catch(Exception ignored){}muxer.release();}if(audioExtractor!=null)audioExtractor.release();if(fd!=null)fd.close();retriever.release();
    }
  }
}
