package com.ryodan.cut;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.content.pm.ActivityInfo;
import android.media.*;
import android.view.*;
import android.widget.*;
import java.nio.ByteBuffer;
import java.util.*;

public class MainActivity extends Activity {
  private static final int PICK=10, SAVE=11;
  private VideoView preview;
  private final TreeMap<Integer,Transform> keyframes=new TreeMap<>();
  private SeekBar zoomBar,xBar,yBar;
  private FrameLayout previewContainer;
  private View cropOverlay;
  private float touchX,touchY,initialDistance;
  private boolean resizing=false;
  private Transform touchStart;
  private TextView keyInfo;
  static class Transform {float zoom,x,y; Transform(float z,float xx,float yy){zoom=z;x=xx;y=yy;} Transform copy(){return new Transform(zoom,x,y);}}
  private Transform current=new Transform(1,0,0);
  private boolean syncing=false;
  private int position(){return preview==null?0:preview.getCurrentPosition();}
  private Transform interpolate(int t){if(keyframes.isEmpty())return new Transform(1,0,0);Map.Entry<Integer,Transform> a=keyframes.floorEntry(t),b=keyframes.ceilingEntry(t);if(a==null)return b.getValue().copy();if(b==null||a.getKey().equals(b.getKey()))return a.getValue().copy();float f=(t-a.getKey())/(float)(b.getKey()-a.getKey());Transform v=a.getValue(),w=b.getValue();return new Transform(v.zoom+(w.zoom-v.zoom)*f,v.x+(w.x-v.x)*f,v.y+(w.y-v.y)*f);}
  private void previewTransform(){if(preview==null)return;Transform t=interpolate(position());preview.setScaleX(t.zoom);preview.setScaleY(t.zoom);preview.setTranslationX(t.x*previewContainer.getWidth()/2f);preview.setTranslationY(t.y*previewContainer.getHeight()/2f);if(cropOverlay!=null)cropOverlay.invalidate();if(keyInfo!=null)keyInfo.setText("◆ "+keyframes.size()+" keyframes  •  "+stamp(position()));}
  private void syncSliders(){if(zoomBar==null)return;syncing=true;Transform t=interpolate(position());zoomBar.setProgress(Math.round((t.zoom-0.25f)*100));xBar.setProgress(Math.round((t.x+1)*100));yBar.setProgress(Math.round((t.y+1)*100));syncing=false;}
  private void updateTransform(){if(syncing)return;current=new Transform(.25f+zoomBar.getProgress()/100f,(xBar.getProgress()-100)/100f,(yBar.getProgress()-100)/100f);keyframes.put(position(),current.copy());previewTransform();}
  private void setTouchTransform(float z,float x,float y){Transform t=new Transform(Math.max(.25f,Math.min(4f,z)),Math.max(-2f,Math.min(2f,x)),Math.max(-2f,Math.min(2f,y)));keyframes.put(position(),t);syncSliders();previewTransform();}
  private void addKey(){keyframes.put(position(),interpolate(position()));syncSliders();previewTransform();}
  private void removeKey(){if(keyframes.isEmpty())return;Integer nearest=keyframes.floorKey(position());if(nearest==null)nearest=keyframes.ceilingKey(position());if(nearest!=null)keyframes.remove(nearest);syncSliders();previewTransform();}
  private SeekBar transformSlider(LinearLayout parent,String name,int max,int initial){LinearLayout row=horizontal();parent.addView(row,new LinearLayout.LayoutParams(-1,dp(27)));TextView l=label(name,10);row.addView(l,new LinearLayout.LayoutParams(dp(75),-2));SeekBar bar=new SeekBar(this);bar.setMax(max);bar.setProgress(initial);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));row.addView(bar,new LinearLayout.LayoutParams(0,dp(27),1));bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}public void onProgressChanged(SeekBar b,int p,boolean user){if(user)updateTransform();}});return bar;}
  private TextView status;
  private SeekBar startBar,endBar,playhead;
  private LinearLayout frames;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final Runnable ticker=new Runnable(){public void run(){if(preview!=null && durationMs>0 && preview.isPlaying()){playhead.setProgress((int)(1000L*preview.getCurrentPosition()/durationMs));timeLabel.setText(stamp(preview.getCurrentPosition())+" / "+stamp(durationMs));previewTransform();}handler.postDelayed(this,200);}};
  private Uri input;
  private long durationMs=0;
  private int startMs=0,endMs=0;
  private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setPadding(dp(12),dp(8),dp(12),dp(8));return t;}
  private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
  private TextView timeLabel, startLabel, endLabel;
  private int bg=0xff101218, panel=0xff1c222b, accent=0xff69d2c5;
  private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private TextView label(String value,int size){TextView t=text(value,size);t.setPadding(dp(6),dp(3),dp(6),dp(3));return t;}
  private Button compact(String value){Button b=button(value);b.setTextSize(11);b.setAllCaps(false);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(7),0,dp(7),0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));b.setTextColor(Color.WHITE);return b;}
  private void openVideo(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
  private void saveVideo(){if(input==null){status.setText("Importe um vídeo primeiro.");return;}if(endMs<=startMs){status.setText("O fim deve ser posterior ao início.");return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("video/mp4");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"RyodanCut_export.mp4");startActivityForResult(i,SAVE);}
  private String stamp(long ms){long seconds=Math.max(0,ms)/1000;return String.format(java.util.Locale.US,"%02d:%02d.%01d",seconds/60,seconds%60,(ms%1000)/100);}
  @Override public void onCreate(Bundle b){super.onCreate(b);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    getWindow().setFlags(1024,1024);getWindow().setNavigationBarColor(bg);
    LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(bg);root.setPadding(dp(10),dp(4),dp(10),dp(3));setContentView(root);
    LinearLayout header=horizontal();root.addView(header,new LinearLayout.LayoutParams(-1,dp(38)));
    TextView title=label("◈  RYODAN CUT  0.6 PAN/CROP",15);title.setTypeface(null,1);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    Button open=compact("+ Vídeo");header.addView(open,new LinearLayout.LayoutParams(dp(92),dp(34)));open.setOnClickListener(v->openVideo());
    Button export=compact("Exportar MP4");export.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff247f77));LinearLayout.LayoutParams ex=new LinearLayout.LayoutParams(dp(125),dp(34));ex.leftMargin=dp(7);header.addView(export,ex);export.setOnClickListener(v->saveVideo());
    LinearLayout middle=horizontal();root.addView(middle,new LinearLayout.LayoutParams(-1,0,1));
    previewContainer=new FrameLayout(this);previewContainer.setBackgroundColor(Color.BLACK);middle.addView(previewContainer,new LinearLayout.LayoutParams(0,-1,7));
    preview=new VideoView(this);previewContainer.addView(preview,new FrameLayout.LayoutParams(-1,-1));
    cropOverlay=new View(this){private final android.graphics.Paint p=new android.graphics.Paint(3);protected void onDraw(android.graphics.Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();Transform t=interpolate(position());float cw=w*.76f/Math.max(.25f,t.zoom),ch=h*.76f/Math.max(.25f,t.zoom);float cx=w*.5f-t.x*w*.5f/Math.max(.25f,t.zoom),cy=h*.5f-t.y*h*.5f/Math.max(.25f,t.zoom);float left=cx-cw/2,top=cy-ch/2,right=cx+cw/2,bottom=cy+ch/2;p.setColor(0xff69d2c5);p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(dp(2));c.drawRect(left,top,right,bottom,p);p.setStyle(android.graphics.Paint.Style.FILL);for(float x:new float[]{left,(left+right)/2,right})for(float y:new float[]{top,bottom})c.drawCircle(x,y,dp(4),p);for(float y:new float[]{(top+bottom)/2})for(float x:new float[]{left,right})c.drawCircle(x,y,dp(4),p);}};
    previewContainer.addView(cropOverlay,new FrameLayout.LayoutParams(-1,-1));
    cropOverlay.setOnTouchListener((v,event)->{if(input==null)return true;switch(event.getActionMasked()){
      case android.view.MotionEvent.ACTION_DOWN:touchX=event.getX();touchY=event.getY();touchStart=interpolate(position());float cw=v.getWidth()*.76f/touchStart.zoom,ch=v.getHeight()*.76f/touchStart.zoom;float right=v.getWidth()*.5f-touchStart.x*v.getWidth()*.5f/touchStart.zoom+cw/2;float bottom=v.getHeight()*.5f-touchStart.y*v.getHeight()*.5f/touchStart.zoom+ch/2;resizing=Math.hypot(event.getX()-right,event.getY()-bottom)<dp(35);return true;
      case android.view.MotionEvent.ACTION_POINTER_DOWN:if(event.getPointerCount()>1){initialDistance=(float)Math.hypot(event.getX(0)-event.getX(1),event.getY(0)-event.getY(1));touchStart=interpolate(position());}return true;
      case android.view.MotionEvent.ACTION_MOVE:if(event.getPointerCount()>1&&initialDistance>1){float d=(float)Math.hypot(event.getX(0)-event.getX(1),event.getY(0)-event.getY(1));setTouchTransform(touchStart.zoom*d/initialDistance,touchStart.x,touchStart.y);}else if(touchStart!=null){if(resizing){float delta=(event.getX()-touchX)/Math.max(1,v.getWidth())+(event.getY()-touchY)/Math.max(1,v.getHeight());setTouchTransform(touchStart.zoom*Math.max(.25f,1f+delta*2),touchStart.x,touchStart.y);}else setTouchTransform(touchStart.zoom,touchStart.x+(event.getX()-touchX)*2/Math.max(1,v.getWidth()),touchStart.y+(event.getY()-touchY)*2/Math.max(1,v.getHeight()));}return true;
      case android.view.MotionEvent.ACTION_UP:case android.view.MotionEvent.ACTION_CANCEL:initialDistance=0;resizing=false;return true;
    }return true;});
    LinearLayout controls=new LinearLayout(this);controls.setOrientation(1);controls.setPadding(dp(12),dp(4),dp(4),0);middle.addView(controls,new LinearLayout.LayoutParams(0,-1,4));
    LinearLayout playback=horizontal();playback.setGravity(Gravity.CENTER);controls.addView(playback,new LinearLayout.LayoutParams(-1,dp(42)));
    Button back=compact("↶ 5s"),play=compact("▶ / ❚❚"),next=compact("5s ↷");playback.addView(back,new LinearLayout.LayoutParams(0,dp(36),1));playback.addView(play,new LinearLayout.LayoutParams(0,dp(36),2));playback.addView(next,new LinearLayout.LayoutParams(0,dp(36),1));
    back.setOnClickListener(v->{if(input!=null)preview.seekTo(Math.max(0,preview.getCurrentPosition()-5000));});next.setOnClickListener(v->{if(input!=null)preview.seekTo((int)Math.min(durationMs,preview.getCurrentPosition()+5000));});
    play.setOnClickListener(v->{if(input==null)return;if(preview.isPlaying())preview.pause();else preview.start();});
    timeLabel=label("00:00.0 / 00:00.0",11);timeLabel.setGravity(Gravity.CENTER);controls.addView(timeLabel,new LinearLayout.LayoutParams(-1,dp(25)));
    startLabel=label("INÍCIO   00:00.0",10);controls.addView(startLabel);startBar=new SeekBar(this);startBar.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));startBar.setThumbTintList(android.content.res.ColorStateList.valueOf(accent));controls.addView(startBar,new LinearLayout.LayoutParams(-1,dp(28)));
    endLabel=label("FIM   00:00.0",10);controls.addView(endLabel);endBar=new SeekBar(this);endBar.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));endBar.setThumbTintList(android.content.res.ColorStateList.valueOf(accent));controls.addView(endBar,new LinearLayout.LayoutParams(-1,dp(28)));
    startBar.setMax(1000);endBar.setMax(1000);endBar.setProgress(1000);startBar.setOnSeekBarChangeListener(listener(true));endBar.setOnSeekBarChangeListener(listener(false));
    LinearLayout keyRow=horizontal();root.addView(keyRow,new LinearLayout.LayoutParams(-1,dp(31)));Button add=compact("◆ Salvar quadro"),remove=compact("Remover ◆");keyRow.addView(add,new LinearLayout.LayoutParams(dp(120),dp(29)));keyRow.addView(remove,new LinearLayout.LayoutParams(dp(110),dp(29)));keyInfo=label("◆ 0 keyframes",10);keyRow.addView(keyInfo);add.setOnClickListener(v->addKey());remove.setOnClickListener(v->removeKey());
    HorizontalScrollView transformScroll=new HorizontalScrollView(this);transformScroll.setHorizontalScrollBarEnabled(false);root.addView(transformScroll,new LinearLayout.LayoutParams(-1,dp(52)));LinearLayout transformControls=horizontal();transformScroll.addView(transformControls);LinearLayout a=new LinearLayout(this);a.setOrientation(1);transformControls.addView(a,new LinearLayout.LayoutParams(dp(270),-2));LinearLayout bControls=new LinearLayout(this);bControls.setOrientation(1);transformControls.addView(bControls,new LinearLayout.LayoutParams(dp(270),-2));zoomBar=transformSlider(a,"Zoom",375,75);xBar=transformSlider(a,"Posição X",200,100);yBar=transformSlider(bControls,"Posição Y",200,100);
    LinearLayout timelineHeader=horizontal();root.addView(timelineHeader,new LinearLayout.LayoutParams(-1,dp(23)));TextView tl=label("TIMELINE",11);tl.setTypeface(null,1);timelineHeader.addView(tl,new LinearLayout.LayoutParams(0,-2,1));TextView hint=label("Arraste • pinça • alça inferior direita",10);hint.setTextColor(0xffa4acb7);timelineHeader.addView(hint);
    HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setFillViewport(true);scroll.setHorizontalScrollBarEnabled(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,dp(54)));frames=horizontal();scroll.addView(frames);
    playhead=new SeekBar(this);playhead.setMax(1000);playhead.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));playhead.setThumbTintList(android.content.res.ColorStateList.valueOf(accent));root.addView(playhead,new LinearLayout.LayoutParams(-1,dp(29)));
    playhead.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int progress,boolean user){if(user&&durationMs>0){preview.seekTo((int)(durationMs*progress/1000));handler.postDelayed(()->{syncSliders();previewTransform();},90);}}});
    status=label("Importe um vídeo para começar.",10);status.setTextColor(0xffa9b5c0);root.addView(status,new LinearLayout.LayoutParams(-1,dp(22)));
  }
  private SeekBar.OnSeekBarChangeListener listener(boolean start){return new SeekBar.OnSeekBarChangeListener(){
    public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
    public void onProgressChanged(SeekBar s,int p,boolean user){if(durationMs<=0)return;int m=(int)(durationMs*p/1000);if(start){startMs=m;if(user)preview.seekTo(startMs);}else endMs=m;startLabel.setText("INÍCIO   "+stamp(startMs));endLabel.setText("FIM   "+stamp(endMs));status.setText("Trecho: "+stamp(startMs)+" — "+stamp(endMs));}
  };}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
    if(req==PICK){input=data.getData();preview.setVideoURI(input);preview.setOnPreparedListener(mp->{durationMs=mp.getDuration();startMs=0;endMs=(int)durationMs;startBar.setProgress(0);endBar.setProgress(1000);status.setText("Vídeo carregado: "+stamp(durationMs));timeLabel.setText("00:00.0 / "+stamp(durationMs));preview.seekTo(1);keyframes.clear();syncSliders();previewTransform();loadFrames(input);});}
    else if(req==SAVE){Uri output=data.getData();int a=startMs,z=endMs;status.setText("Exportando...");new Thread(()->{String message;try{if(keyframes.isEmpty())export(input,output,a,z);else AnimatedExporter.export(this,input,output,a,z,new TreeMap<>(keyframes));message="MP4 exportado com sucesso.";}catch(Exception e){message="Falha na exportação: "+e.getMessage();}final String m=message;runOnUiThread(()->status.setText(m));}).start();}
  }
  private void loadFrames(Uri uri){
    frames.removeAllViews();
    new Thread(()->{
      MediaMetadataRetriever retriever=new MediaMetadataRetriever();
      try{retriever.setDataSource(this,uri);int n=12;
        for(int i=0;i<n;i++){
          final int index=i;long time=(long)((durationMs*1000.0*i)/n);
          Bitmap bitmap=retriever.getFrameAtTime(time,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
          if(bitmap!=null){runOnUiThread(()->{ImageView view=new ImageView(this);view.setImageBitmap(bitmap);view.setScaleType(ImageView.ScaleType.CENTER_CROP);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(92),dp(52));lp.setMargins(dp(1),0,dp(1),0);frames.addView(view,lp);view.setOnClickListener(v->{int ms=(int)(durationMs*index/n);preview.seekTo(ms);playhead.setProgress((int)(1000L*ms/durationMs));handler.postDelayed(()->{syncSliders();previewTransform();},100);});});}
        }
      }catch(Exception e){runOnUiThread(()->status.setText("Miniaturas indisponíveis: "+e.getMessage()));}
      finally{try{retriever.release();}catch(Exception ignored){}}
    }).start();
  }
  @Override protected void onResume(){super.onResume();handler.post(ticker);}
  @Override protected void onPause(){handler.removeCallbacks(ticker);if(preview!=null)preview.pause();super.onPause();}
  private void export(Uri source,Uri dest,long start,long end)throws Exception{
    MediaExtractor extractor=new MediaExtractor();MediaMuxer muxer=null;
    try{
      extractor.setDataSource(this,source,null);
      android.os.ParcelFileDescriptor fd=getContentResolver().openFileDescriptor(dest,"w");
      if(fd==null)throw new Exception("Destino indisponível");
      try{
        muxer=new MediaMuxer(fd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int count=extractor.getTrackCount();int[] mapped=new int[count];java.util.Arrays.fill(mapped,-1);
        int maxSize=1024*1024;
        for(int i=0;i<count;i++){MediaFormat f=extractor.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);
          if(mime!=null&&(mime.startsWith("video/")||mime.startsWith("audio/"))){mapped[i]=muxer.addTrack(f);extractor.selectTrack(i);if(f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))maxSize=Math.max(maxSize,f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));}}
        muxer.start();extractor.seekTo(start*1000,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        ByteBuffer buf=ByteBuffer.allocateDirect(maxSize);MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        long base=-1;
        while(true){int track=extractor.getSampleTrackIndex();if(track<0)break;long t=extractor.getSampleTime();if(t<0||t>end*1000)break;
          if(mapped[track]<0){extractor.advance();continue;}
          buf.clear();int size=extractor.readSampleData(buf,0);if(size<0)break;
          if(base<0)base=t;
          info.offset=0;info.size=size;info.presentationTimeUs=Math.max(0,t-base);info.flags=extractor.getSampleFlags();
          muxer.writeSampleData(mapped[track],buf,info);extractor.advance();
        }
        muxer.stop();muxer.release();muxer=null;
      }finally{fd.close();}
    }finally{extractor.release();if(muxer!=null)try{muxer.release();}catch(Exception ignored){}}
  }
}
