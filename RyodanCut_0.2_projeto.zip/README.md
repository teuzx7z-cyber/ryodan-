# Ryodan Cut 0.6 — POCO X6 Pro (experimental)

Projeto Android Java, destinado a uso em modo horizontal no POCO X6 Pro com HyperOS 3.

## Alterações
- Pan/Crop visual: arrastar para deslocar, pinça para zoom, alça inferior direita para ajustar escala.
- Moldura que acompanha os keyframes de posição e zoom (sem rotação).
- Keyframes interpolados linearmente.
- Exportador experimental configurado para H.264 30 FPS, limitado a 1920×1080, com cópia de áudio AAC/MP3 quando presente.
- Fluxo GitHub Actions para compilar APK de debug.

## Limitações importantes
- O exportador utiliza Canvas.lockCanvas() na superfície do encoder MediaCodec. Esse caminho **pode não ser suportado** pelo codec do aparelho. A exportação animada ainda não foi validada em um POCO X6 Pro.
- Não foi possível compilar nem executar este projeto neste ambiente. Não considerar o APK ou a exportação como validados.
- Áudio com codecs diferentes de AAC/MP3 não é copiado.
- A exportação ainda é limitada à proporção e orientação que o extrator de frames entrega; vídeos com metadados de rotação precisam de teste.
- O preview VideoView usa uma SurfaceView e suas transformações podem não corresponder perfeitamente à renderização do MP4.

## Build
Suba os arquivos da pasta `ryodan_keyframes` para a raiz do repositório. Em GitHub Actions, execute `Build Android APK` e baixe o artifact `RyodanCut-debug-apk`.

## Teste recomendado
Importe um vídeo horizontal de 5 segundos em H.264 com áudio AAC; crie um keyframe no início e outro no fim com zoom diferente; exporte e verifique imagem, duração e som.
