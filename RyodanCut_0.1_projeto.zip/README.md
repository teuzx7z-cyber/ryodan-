# Ryodan Cut 0.1 — Android

Protótipo Android Java sem dependências externas de edição.

## Funções
- Importar um vídeo pelo seletor Android
- Reproduzir e visualizar
- Definir início e fim com controles
- Exportar vídeo MP4 usando MediaExtractor + MediaMuxer sem recodificação

**Limitações:** um vídeo por vez; sem múltiplas faixas, efeitos ou Pan/Crop; os cortes usam keyframes e podem não ser exatos. Nem todos os codecs/arquivos são compatíveis com MP4 muxing. Não há garantia de sincronização em todos os arquivos.

## APK no celular
1. Envie o conteúdo desta pasta para a raiz do repositório GitHub, mantendo `.github/workflows/android.yml`.
2. Abra Actions > Build Android APK.
3. Abra a execução bem-sucedida e baixe o artifact `RyodanCut-debug-apk`.
4. Extraia o ZIP do artifact e instale `app-debug.apk`.

O workflow compila um APK de depuração. Esta versão não foi compilada/testada neste ambiente.
