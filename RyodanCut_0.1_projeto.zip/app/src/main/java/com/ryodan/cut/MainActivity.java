package com.ryodan.cut;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.media.*;
import android.view.*;
import android.widget.*;
import java.nio.ByteBuffer;

public class MainActivity extends Activity {
  private static final int PICK=10, SAVE=11;
  private VideoView preview;
  private TextView status;
  private SeekBar startBar,endBar;
  private Uri input;
  private long durationMs=0;
  private int startMs=0,endMs=0;
  private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setPadding(dp(12),dp(8),dp(12),dp(8));return t;}
  private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
  @Override public void onCreate(Bundle b){super.onCreate(b);
    getWindow().setStatusBarColor(0xff11131a);getWindow().setNavigationBarColor(0xff11131a);
    LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(0xff151821);root.setPadding(dp(12),dp(8),dp(12),dp(8));setContentView(root);
    root.addView(text("RYODAN CUT  •  versão 0.1",21));
    preview=new VideoView(this);root.addView(preview,new LinearLayout.LayoutParams(-1,0,1));
    Button open=button("Importar vídeo");root.addView(open);open.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);});
    Button play=button("▶ Reproduzir / Pausar");root.addView(play);play.setOnClickListener(v->{if(input==null)return;if(preview.isPlaying())preview.pause();else preview.start();});
    root.addView(text("Início do corte",14));startBar=new SeekBar(this);root.addView(startBar);
    root.addView(text("Fim do corte",14));endBar=new SeekBar(this);root.addView(endBar);
    startBar.setMax(1000);endBar.setMax(1000);endBar.setProgress(1000);
    startBar.setOnSeekBarChangeListener(listener(true));endBar.setOnSeekBarChangeListener(listener(false));
    Button export=button("Exportar trecho MP4");root.addView(export);export.setOnClickListener(v->{if(input==null){status.setText("Importe um vídeo primeiro.");return;}if(endMs<=startMs){status.setText("O fim deve ser posterior ao início.");return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("video/mp4");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"RyodanCut_export.mp4");startActivityForResult(i,SAVE);});
    status=text("Importe um vídeo para começar.",13);root.addView(status);
  }
  private SeekBar.OnSeekBarChangeListener listener(boolean start){return new SeekBar.OnSeekBarChangeListener(){
    public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
    public void onProgressChanged(SeekBar s,int p,boolean user){if(durationMs<=0)return;int m=(int)(durationMs*p/1000);if(start){startMs=m;if(user)preview.seekTo(startMs);}else endMs=m;status.setText("Trecho: "+startMs/1000+"s — "+endMs/1000+"s");}
  };}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
    if(req==PICK){input=data.getData();preview.setVideoURI(input);preview.setOnPreparedListener(mp->{durationMs=mp.getDuration();startMs=0;endMs=(int)durationMs;startBar.setProgress(0);endBar.setProgress(1000);status.setText("Vídeo carregado: "+(durationMs/1000)+" segundos");preview.seekTo(1);});}
    else if(req==SAVE){Uri output=data.getData();int a=startMs,z=endMs;status.setText("Exportando...");new Thread(()->{String message;try{export(input,output,a,z);message="MP4 exportado com sucesso.";}catch(Exception e){message="Falha na exportação: "+e.getMessage();}final String m=message;runOnUiThread(()->status.setText(m));}).start();}
  }
  private void export(Uri source,Uri dest,long start,long end)throws Exception{
    MediaExtractor extractor=new MediaExtractor();MediaMuxer muxer=null;
    try{
      extractor.setDataSource(this,source,null);
      android.os.ParcelFileDescriptor fd=getContentResolver().openFileDescriptor(dest,"w");
      if(fd==null)throw new Exception("Destino indisponível");
      try{
        muxer=new MediaMuxer(fd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int count=extractor.getTrackCount();int[] mapped=new int[count];java.util.Arrays.fill(mapped,-1);
        int maxSize=1024*1024;
        for(int i=0;i<count;i++){MediaFormat f=extractor.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);
          if(mime!=null&&(mime.startsWith("video/")||mime.startsWith("audio/"))){mapped[i]=muxer.addTrack(f);extractor.selectTrack(i);if(f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))maxSize=Math.max(maxSize,f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));}}
        muxer.start();extractor.seekTo(start*1000,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        ByteBuffer buf=ByteBuffer.allocateDirect(maxSize);MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        long base=-1;
        while(true){int track=extractor.getSampleTrackIndex();if(track<0)break;long t=extractor.getSampleTime();if(t<0||t>end*1000)break;
          if(mapped[track]<0){extractor.advance();continue;}
          buf.clear();int size=extractor.readSampleData(buf,0);if(size<0)break;
          if(base<0)base=t;
          info.offset=0;info.size=size;info.presentationTimeUs=Math.max(0,t-base);info.flags=extractor.getSampleFlags();
          muxer.writeSampleData(mapped[track],buf,info);extractor.advance();
        }
        muxer.stop();muxer.release();muxer=null;
      }finally{fd.close();}
    }finally{extractor.release();if(muxer!=null)try{muxer.release();}catch(Exception ignored){}}
  }
}
